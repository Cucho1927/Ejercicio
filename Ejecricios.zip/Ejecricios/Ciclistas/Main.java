import java.util.ArrayList;
import java.util.Scanner;

abstract class Ciclista {
    private int id;
    private String nombre;
    private int tiempoAcumulado;

    public Ciclista(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.tiempoAcumulado = 0;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getTiempoAcumulado() {
        return tiempoAcumulado;
    }

    public void setTiempoAcumulado(int tiempoAcumulado) {
        this.tiempoAcumulado = tiempoAcumulado;
    }

    public abstract String imprimirTipo();
}

class Velocista extends Ciclista {
    private double potenciaPromedio;
    private double velocidadPromedioSprint;

    public Velocista(int id, String nombre, double potenciaPromedio, double velocidadPromedioSprint) {
        super(id, nombre);
        this.potenciaPromedio = potenciaPromedio;
        this.velocidadPromedioSprint = velocidadPromedioSprint;
    }

    public double getPotenciaPromedio() {
        return potenciaPromedio;
    }

    public double getVelocidadPromedioSprint() {
        return velocidadPromedioSprint;
    }

    @Override
    public String imprimirTipo() {
        return "es un Velocista";
    }
}

class Escalador extends Ciclista {
    private float aceleracionPromedioSubida;
    private float gradoRampaSoportada;

    public Escalador(int id, String nombre, float aceleracionPromedioSubida, float gradoRampaSoportada) {
        super(id, nombre);
        this.aceleracionPromedioSubida = aceleracionPromedioSubida;
        this.gradoRampaSoportada = gradoRampaSoportada;
    }

    public float getAceleracionPromedioSubida() {
        return aceleracionPromedioSubida;
    }

    public float getGradoRampaSoportada() {
        return gradoRampaSoportada;
    }

    @Override
    public String imprimirTipo() {
        return "es un Escalador";
    }
}

class Contrarrelojista extends Ciclista {
    private double velocidadMaxima;

    public Contrarrelojista(int id, String nombre, double velocidadMaxima) {
        super(id, nombre);
        this.velocidadMaxima = velocidadMaxima;
    }

    public double getVelocidadMaxima() {
        return velocidadMaxima;
    }

    @Override
    public String imprimirTipo() {
        return "es un Contrarrelojista";
    }
}

class Equipo {
    private String nombreEquipo;
    private String paisEquipo;
    private static int tiempoTotalCarrera;
    private ArrayList<Ciclista> ciclistas = new ArrayList<>();

    public Equipo(String nombreEquipo, String paisEquipo) {
        this.nombreEquipo = nombreEquipo;
        this.paisEquipo = paisEquipo;
    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
    }

    public String getPaisEquipo() {
        return paisEquipo;
    }

    public void setPaisEquipo(String paisEquipo) {
        this.paisEquipo = paisEquipo;
    }

    public static int getTiempoTotalCarrera() {
        return tiempoTotalCarrera;
    }

    public static void setTiempoTotalCarrera(int tiempoTotalCarrera) {
        Equipo.tiempoTotalCarrera = tiempoTotalCarrera;
    }

    public void agregarCiclista(Ciclista ciclista) {
        ciclistas.add(ciclista);
        tiempoTotalCarrera += ciclista.getTiempoAcumulado();
    }

    public void imprimirDatosEquipo() {
        System.out.println("Nombre del equipo: " + nombreEquipo);
        System.out.println("País del equipo: " + paisEquipo);
        System.out.println("Tiempo total de carrera del equipo: " + tiempoTotalCarrera);
    }

    public void listarCiclistas() {
        System.out.println("Ciclistas del equipo:");
        for (Ciclista ciclista : ciclistas) {
            System.out.println("- " + ciclista.getNombre());
        }
    }

    public void imprimirDatosCiclista(int id) {
        boolean encontrado = false;
        for (Ciclista ciclista : ciclistas) {
            if (ciclista.getId() == id) {
                encontrado = true;
                System.out.println("Datos del ciclista:");
                System.out.println("Nombre: " + ciclista.getNombre());
                System.out.println("Tiempo acumulado: " + ciclista.getTiempoAcumulado());
                System.out.println(ciclista.imprimirTipo());
                break;
            }
        }
        if (!encontrado) {
            System.out.println("Ciclista no encontrado");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Equipo equipo = new Equipo("Equipo A", "País A");

        Velocista velo = new Velocista(1, "Velocista1", 250.5, 40.5);
        Escalador esca = new Escalador(2, "Escalador1", 9.8f, 10.5f);
        Contrarrelojista contra = new Contrarrelojista(3, "Contrarrelojista1", 55.2);

        equipo.agregarCiclista(velo);
        equipo.agregarCiclista(esca);
        equipo.agregarCiclista(contra);

        equipo.imprimirDatosEquipo();
        equipo.listarCiclistas();

        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el ID del ciclista a buscar: ");
        int idCiclista = scanner.nextInt();
        equipo.imprimirDatosCiclista(idCiclista);
    }
}
